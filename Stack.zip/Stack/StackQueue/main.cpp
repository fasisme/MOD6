#include <iostream>
#include "sq.h"
#include "sq.cpp"

using namespace std;

void mainMenu(Stack S){
    address p;
    infotype x;
    int pil;
    do {
        cout << "1. input data"<<endl;
        cout << "2. cek stack"<<endl;
        cout << "3. hapus data"<<endl;
        cout << "4. print data"<<endl;
        cout << "0. exit"<<endl;
        cout << "pilih: ";
        cin >> pil;
        switch (pil){
        case 1:
            cout << "Masukkan data: ";
            cin >> x;
            createNewElm(x,p);
            push(S,p);
            break;
        case 2:
            if (emptyStack(S)){
                cout << "stack kosong"<<endl;
            }else {
                cout << "stack tidak kosong"<<endl;
            }
            break;
        case 3:
            pop(S,p);
            break;
        case 4:
            printInfo(S);
            break;
        case 0:break;
        default:break;
        }
    } while (pil != 0);
}

int main()
{
    Stack S;
    createStack(S);
    mainMenu(S);

    return 0;
}
