#include "sq.h"

bool emptyStack(Stack S){
    if (top(S) == NULL){
        return true;
    } else {
        return false;
    }
}
void createStack(Stack &S){
    top(S) = NULL;
}
void createNewElm(infotype x, address &p){
    p = new elmStack;
    info(p) = x;
    next(p) = NULL;
}
void push(Stack &S, address p){
    if (emptyStack(S)){
        top(S) = p;
    } else {
        next(p) = top(S);
        top(S) = p;
    }
}
void pop(Stack &S, address &p){
    if (emptyStack(S)){
        cout<< "stack kosong" <<endl;
    } else {
        p = top(S);
        top(S) = next(p);
        next(p) = NULL;
    }
}
void printInfo(Stack S){
    if (emptyStack(S) != true){
        address p = top(S);
        while(p != NULL){
            cout << info(p) << " ";
            p = next(p);
        }
    } else {
        cout << "stack kosong"<<endl;
    }
    cout<<endl;
    
}
